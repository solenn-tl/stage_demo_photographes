#Leafet GeoJSON Filter Test

This is a repository of test code for the leaflet control at https://github.com/guygriffiths/leaflet-geojson-filter

It illustrates how to use JSPM to depend on the library and use it in a very simple example.  Code is provided 'as is', and is primarily for my own reference, but if you have any questions or issues using it, please let me know.
